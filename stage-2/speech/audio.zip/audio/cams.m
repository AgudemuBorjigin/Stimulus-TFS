function E = cams(f)
E = 21.4 * log10(0.00437 * f + 1);
end