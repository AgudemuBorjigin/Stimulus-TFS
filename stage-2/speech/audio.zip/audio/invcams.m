function f = invcams(E)
f = (10.^(E/21.4) - 1)/0.00437;
end
